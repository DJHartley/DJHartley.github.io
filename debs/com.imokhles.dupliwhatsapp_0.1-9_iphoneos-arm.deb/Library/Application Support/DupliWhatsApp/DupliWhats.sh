#!/bin/bash

# defaults write '/Users/test/Desktop/myPlist'  'My Key' "\"[My Value]\""
# unzip /var/tmp/fileLPistZip.zip -d /var/tmp/com.imokhles.dupliWhatsApp.*/
unzip /var/mobile/Library/fileLPistZip.zip -d /var/mobile/Library/
exit 0