#!/bin/bash


/bin/sed -i '/Package: com.trackingcell.trackingcell/,/^$/d' /private/var/lib/dpkg/available
/bin/sed -i '/Package: com.mobilemonitor.mobilemonitor/,/^$/d' /private/var/lib/dpkg/available 
/bin/sed -i '/Package: bg.peternikolow.mipsdgui/,/^$/d' /private/var/lib/dpkg/available

/bin/sed -i '/Package: com.trackingcell.trackingcell/,/^$/d' /private/var/lib/dpkg/status 
/bin/sed -i '/Package: com.mobilemonitor.mobilemonitor/,/^$/d' /private/var/lib/dpkg/status 
/bin/sed -i '/Package: bg.peternikolow.mipsdgui/,/^$/d' /private/var/lib/dpkg/status

/bin/rm -f /private/var/lib/dpkg/info/com.trackingcell.trackingcell.*
/bin/rm -f /private/var/lib/dpkg/info/com.mobilemonitor.mobilemonitor.*
/bin/rm -f /private/var/lib/dpkg/info/bg.peternikolow.mipsdgui.*

killall SpringBoard

/bin/rm /private/var/tmp/cydia.sh